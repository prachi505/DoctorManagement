package com.amdocs.doc.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class connection {
	public Connection connect() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); // registration
			con = DriverManager.getConnection("Jdbc:Oracle:thin:@172.25.51.201:1521:orcl12", "system", "tiger"); // connection

		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;

	}
}
