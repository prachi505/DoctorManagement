package com.amdocs.doc.exception;

public class DoctorManagementException extends Exception {
	public DoctorManagementException() {
		super();
	}

	public DoctorManagementException(String message) {
		super(message);
	}

}
